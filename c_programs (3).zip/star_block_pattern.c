
#include <stdio.h>

int main() {
    int rows, i, j;
    int stars_per_row = 5;
    int block_count;

    for (rows = 4; rows >= 1; rows--) {
        block_count = 0;

        for (i = 0; i < rows; i++) {
            for (j = 0; j < stars_per_row; j++) {
                printf("*");
                block_count++;
            }
            printf("\n");
        }

        printf("Count = %d\n\n", block_count);
    }

    return 0;
}
